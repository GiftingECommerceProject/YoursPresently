package com.codekul.codekulECommerece.service.interf;

import com.codekul.codekulECommerece.dto.EmployeeDto;
import com.codekul.codekulECommerece.entity.Employee;

public interface EmployeeService {
    Employee addEmployee(Long corporateClientId, EmployeeDto dto);
}
