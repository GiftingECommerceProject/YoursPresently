package com.codekul.codekulECommerece.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.codekul.codekulECommerece.entity.Employee;

public interface EmployeeRepository extends JpaRepository<Employee, Long> {
    // Add any custom query methods if needed
}
