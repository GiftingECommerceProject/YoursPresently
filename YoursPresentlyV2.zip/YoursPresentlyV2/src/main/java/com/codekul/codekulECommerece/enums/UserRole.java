package com.codekul.codekulECommerece.enums;

public enum UserRole {
    ADMIN, USER, VENDOR, ORGANISATION
}
