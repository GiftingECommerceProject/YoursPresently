package com.codekul.codekulECommerece;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.Bean;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.datatype.jsr310.JavaTimeModule;

@SpringBootApplication
public class CodekulECommereceApplication {

	public static void main(String[] args) {
		SpringApplication.run(CodekulECommereceApplication.class, args);
		
	}
	@Bean
	public ObjectMapper objectMapper() {
	    return new ObjectMapper().registerModule(new JavaTimeModule());
	}
}
