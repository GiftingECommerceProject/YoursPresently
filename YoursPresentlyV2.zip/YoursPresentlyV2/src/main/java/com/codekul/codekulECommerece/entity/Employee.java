package com.codekul.codekulECommerece.entity;
//
//import jakarta.persistence.*;
//import lombok.*;
//
//import java.time.LocalDate;
//
//@Entity
//@Table(name = "employees")
//@Getter
//@Setter
//@NoArgsConstructor
//@AllArgsConstructor
//public class Employee {
//
//    @Id
//    @GeneratedValue(strategy = GenerationType.IDENTITY)
//    private Long id;
//
//    private String name;
//    private LocalDate birthdate;
//
//    @ManyToOne
//    @JoinColumn(name = "corporate_client_id", nullable = false)
//    private CorporateClient corporateClient;
//}

import java.time.LocalDate;

import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;


@Entity
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
public class Employee {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    private String name;
    private String email;
    private LocalDate birthdate;

    @ManyToOne
    @JoinColumn(name = "corporate_client_id")
    private CorporateClient corporateClient;

	

	

	
    
    // Getters and setters
}


