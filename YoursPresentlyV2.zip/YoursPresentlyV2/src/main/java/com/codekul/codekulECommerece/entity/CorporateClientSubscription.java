package com.codekul.codekulECommerece.entity;

import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.OneToOne;

@Entity
public class CorporateClientSubscription {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;
    private String planType; // e.g., Monthly, Yearly
    private Double price;
    
    @OneToOne
    @JoinColumn(name = "corporate_client_id")
    private CorporateClient corporateClient;
}
