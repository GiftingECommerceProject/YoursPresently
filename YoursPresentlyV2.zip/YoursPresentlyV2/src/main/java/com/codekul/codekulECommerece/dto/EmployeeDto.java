package com.codekul.codekulECommerece.dto;
//
//import lombok.*;
//
//import java.time.LocalDate;
//
//@Getter
//@Setter
//@NoArgsConstructor
//@AllArgsConstructor
//public class EmployeeDto {
//    private String name;
//    private LocalDate birthdate;
//}

import java.time.LocalDate;

import com.fasterxml.jackson.annotation.JsonFormat;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
public class EmployeeDto {
    private String name;
    private String email;
    @JsonFormat(shape = JsonFormat.Shape.STRING, pattern = "yyyy-MM-dd")
    private LocalDate birthDate;
	public void setBirthDate(LocalDate birthdate2) {
		// TODO Auto-generated method stub
		this.birthDate=birthdate2;
	}
	
}
