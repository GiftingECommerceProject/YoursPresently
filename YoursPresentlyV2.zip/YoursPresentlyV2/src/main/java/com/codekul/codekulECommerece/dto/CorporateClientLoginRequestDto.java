package com.codekul.codekulECommerece.dto;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter

public class CorporateClientLoginRequestDto {
    private String email;
    private String password;

    // Getters and Setters
}
