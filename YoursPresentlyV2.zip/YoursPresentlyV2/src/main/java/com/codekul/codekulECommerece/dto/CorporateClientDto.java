package com.codekul.codekulECommerece.dto;
//
//import lombok.AllArgsConstructor;
//import lombok.Getter;
//import lombok.NoArgsConstructor;
//import lombok.Setter;
//
////
////import lombok.*;
////
////@Getter
////@Setter
////@NoArgsConstructor
////@AllArgsConstructor
////public class CorporateClientDto {
////    private String companyName;
////    private String companyEmail;
////    private String companyPhone;
////    private String password;
////}
//
//@Getter
//@Setter
//@NoArgsConstructor
//@AllArgsConstructor
//public class CorporateClientDto {
//    private Long id;
//    private String companyName;
//    private String contactEmail;
//    private String contactNumber;
//    private String address;
//}
import java.util.List;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
public class CorporateClientDto {
    private Long id;
    private String name;
    private String email;
    private String password;
    private List<EmployeeDto> employees;
    
    // Getters and setters



}
