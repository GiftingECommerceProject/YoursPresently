package com.codekul.codekulECommerece.service.interf;

import com.codekul.codekulECommerece.dto.CorporateClientDto;
import com.codekul.codekulECommerece.entity.CorporateClient;

public interface CorporateClientService {
    CorporateClient registerCorporateClient(CorporateClientDto dto);
}
