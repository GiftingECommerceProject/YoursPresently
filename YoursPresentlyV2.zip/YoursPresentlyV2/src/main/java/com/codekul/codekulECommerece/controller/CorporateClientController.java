package com.codekul.codekulECommerece.controller;
//
//import com.codekul.codekulECommerece.dto.CorporateClientDto;
//import com.codekul.codekulECommerece.entity.CorporateClient;
//import com.codekul.codekulECommerece.service.impl.CorporateClientServiceImpl;
//import lombok.RequiredArgsConstructor;
//import org.springframework.http.HttpStatus;
//import org.springframework.http.ResponseEntity;
//import org.springframework.web.bind.annotation.*;
//
//@RestController
//@RequestMapping("/corporate-clients")
//@RequiredArgsConstructor
//public class CorporateClientController {
//
//    private final CorporateClientServiceImpl corporateClientService;
//
//    @PostMapping("/register")
//    public ResponseEntity<CorporateClient> registerCorporateClient(@RequestBody CorporateClientDto dto) {
//        CorporateClient corporateClient = corporateClientService.registerCorporateClient(dto);
//        return ResponseEntity.status(HttpStatus.CREATED).body(corporateClient);
//    }
//}
import org.apache.http.HttpStatus;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.codekul.codekulECommerece.dto.CorporateClientDto;
import com.codekul.codekulECommerece.dto.EmployeeDto;
import com.codekul.codekulECommerece.dto.LoginRequestDto;
import com.codekul.codekulECommerece.service.impl.CorporateClientService;
@RestController
@CrossOrigin(origins = "http://localhost:3000")
@RequestMapping("/api/corporate-clients")
public class CorporateClientController {

    @Autowired
    private CorporateClientService corporateClientService;

    // Login Endpoint
//    @PostMapping("/login")
//    public ResponseEntity<CorporateClientDto> login(@RequestParam String email, @RequestParam String password) {
//        CorporateClientDto corporateClientDto = corporateClientService.login(email, password);
//        return ResponseEntity.ok(corporateClientDto);
//    }
    @PostMapping("/login")
    public ResponseEntity<CorporateClientDto> login(@RequestBody LoginRequestDto loginRequest) {
        CorporateClientDto corporateClientDto = corporateClientService.login(loginRequest.getEmail(), loginRequest.getPassword());
        return ResponseEntity.ok(corporateClientDto);
    }


    // Registration Endpoint
    @PostMapping("/register")
    public ResponseEntity<Void> register(@RequestBody CorporateClientDto corporateClientDto) {
        corporateClientService.registerCorporateClient(corporateClientDto);
        return ResponseEntity.status(HttpStatus.SC_CREATED).build();
    }

    // Add Employee Endpoint
    @PostMapping("/{corporateClientId}/employees")
    public ResponseEntity<Void> addEmployee(@PathVariable Long corporateClientId, @RequestBody EmployeeDto employeeDto) {
        corporateClientService.addEmployeeToCorporateClient(corporateClientId, employeeDto);
        return ResponseEntity.status(HttpStatus.SC_CREATED).build();
    }

    // Send Birthday Emails



@Scheduled(cron = "0 0 0 * * ?")
    @GetMapping("/send-birthday-emails")
    public ResponseEntity<Void> sendBirthdayEmails() {
        corporateClientService.sendBirthdayEmails();
        return ResponseEntity.ok().build();
    }
}
