package com.codekul.codekulECommerece.service.impl;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.mail.SimpleMailMessage;
import org.springframework.mail.javamail.JavaMailSender;
import org.springframework.stereotype.Service;

import com.codekul.codekulECommerece.entity.Employee;

@Service
public class EmailService {

    @Autowired
    private JavaMailSender mailSender;

    public void sendBirthdayEmail(Employee employee) {
        String subject = "Happy Birthday, " + employee.getName() + "!";
        String text = "Dear " + employee.getName() + ",\n\nWishing you a wonderful birthday!\n\nBest Regards,\nYour Company";
        
        SimpleMailMessage message = new SimpleMailMessage();
        message.setTo(employee.getEmail());
        message.setSubject(subject);
        message.setText(text);
        
        mailSender.send(message);
    }
}
