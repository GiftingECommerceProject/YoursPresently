package com.codekul.codekulECommerece.repository;

import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;

import com.codekul.codekulECommerece.entity.CorporateClient;

public interface CorporateClientRepository extends JpaRepository<CorporateClient, Long> {
    Optional<CorporateClient> findByEmailAndPassword(String email, String password);
}
