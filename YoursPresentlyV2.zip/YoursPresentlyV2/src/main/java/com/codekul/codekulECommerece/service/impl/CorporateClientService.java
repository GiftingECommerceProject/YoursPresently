package com.codekul.codekulECommerece.service.impl;

import java.time.LocalDate;
import java.util.List;
import java.util.stream.Collectors;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.codekul.codekulECommerece.dto.CorporateClientDto;
import com.codekul.codekulECommerece.dto.EmployeeDto;
import com.codekul.codekulECommerece.entity.CorporateClient;
import com.codekul.codekulECommerece.entity.Employee;
import com.codekul.codekulECommerece.repository.CorporateClientRepository;
import com.codekul.codekulECommerece.repository.EmployeeRepository;

//
//import com.codekul.codekulECommerece.dto.CorporateClientDto;
//import com.codekul.codekulECommerece.entity.CorporateClient;
//import com.codekul.codekulECommerece.repository.CorporateClientRepo;
//import com.codekul.codekulECommerece.service.interf.CorporateClientService;
//import lombok.RequiredArgsConstructor;
//import org.springframework.security.crypto.password.PasswordEncoder;
//import org.springframework.stereotype.Service;
//
//@Service
//@RequiredArgsConstructor
//public class CorporateClientServiceImpl implements CorporateClientService {
//
//    private final CorporateClientRepo corporateClientRepo;
//    private final PasswordEncoder passwordEncoder;
//
//    @Override
//    public CorporateClient registerCorporateClient(CorporateClientDto dto) {
//        CorporateClient client = new CorporateClient();
//        client.setCompanyName(dto.getCompanyName());
//        client.setCompanyEmail(dto.getCompanyEmail());
//        client.setCompanyPhone(dto.getCompanyPhone());
//        client.setPassword(passwordEncoder.encode(dto.getPassword())); // Secure password
//
//        return corporateClientRepo.save(client);
//    }
//}

@Service
public class CorporateClientService {

    @Autowired
    private CorporateClientRepository corporateClientRepository;

    @Autowired
    private EmployeeRepository employeeRepository;

    @Autowired
    private EmailService emailService;

    public CorporateClientDto login(String email, String password) {
        CorporateClient corporateClient = corporateClientRepository.findByEmailAndPassword(email, password)
                .orElseThrow(() -> new RuntimeException("Invalid credentials"));
        return mapToDto(corporateClient);
    }

    public void registerCorporateClient(CorporateClientDto corporateClientDto) {
        CorporateClient corporateClient = new CorporateClient();
        corporateClient.setName(corporateClientDto.getName());
        corporateClient.setEmail(corporateClientDto.getEmail());
        corporateClient.setPassword(corporateClientDto.getPassword()); // Ensure you handle password encoding



corporateClientRepository.save(corporateClient);
    }
    

    public void addEmployeeToCorporateClient(Long corporateClientId, EmployeeDto employeeDto) {
        CorporateClient corporateClient = corporateClientRepository.findById(corporateClientId)
                .orElseThrow(() -> new RuntimeException("Corporate client not found"));

        Employee employee = new Employee();
        employee.setName(employeeDto.getName());
        employee.setEmail(employeeDto.getEmail());
        employee.setBirthdate(employeeDto.getBirthDate());
        employee.setCorporateClient(corporateClient);

        corporateClient.getEmployees().add(employee);
        corporateClientRepository.save(corporateClient);
    }

    public void sendBirthdayEmails() {
        List<Employee> employees = employeeRepository.findAll();
        for (Employee employee : employees) {
            if (isTodayBirthday(employee.getBirthdate())) {
                emailService.sendBirthdayEmail(employee);
            }
        }
    }

    private boolean isTodayBirthday(LocalDate localDate) {
        LocalDate today = LocalDate.now();
        LocalDate employeeBirthdate = localDate;
        return today.getMonth() == employeeBirthdate.getMonth() && today.getDayOfMonth() == employeeBirthdate.getDayOfMonth();
    }

    private CorporateClientDto mapToDto(CorporateClient corporateClient) {
        CorporateClientDto dto = new CorporateClientDto();
        dto.setId(corporateClient.getId());
        dto.setName(corporateClient.getName());
        dto.setEmail(corporateClient.getEmail());
        dto.setEmployees(corporateClient.getEmployees().stream()
                .map(this::mapEmployeeToDto)
                .collect(Collectors.toList()));
        return dto;
    }

    private EmployeeDto mapEmployeeToDto(Employee employee) {
        EmployeeDto dto = new EmployeeDto();
//        dto.setId(employee.getId());
        dto.setName(employee.getName());
        dto.setEmail(employee.getEmail());
        dto.setBirthDate(employee.getBirthdate());
        return dto;
    }
}

