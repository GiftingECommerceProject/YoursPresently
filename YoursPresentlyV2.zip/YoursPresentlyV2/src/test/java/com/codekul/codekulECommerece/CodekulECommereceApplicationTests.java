package com.codekul.codekulECommerece;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CodekulECommereceApplicationTests {

	@Test
	void contextLoads() {
	}

}
