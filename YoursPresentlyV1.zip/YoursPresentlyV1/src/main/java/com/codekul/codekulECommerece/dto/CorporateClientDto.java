package com.codekul.codekulECommerece.dto;

import lombok.*;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
public class CorporateClientDto {
    private String companyName;
    private String companyEmail;
    private String companyPhone;
    private String password;
}
