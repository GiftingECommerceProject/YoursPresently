package com.codekul.codekulECommerece.entity;

import jakarta.persistence.*;
import lombok.*;

import java.util.ArrayList;
import java.util.List;

import com.fasterxml.jackson.annotation.JsonIgnore;

@Entity
@Table(name = "corporate_clients")
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
public class CorporateClient {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    private String companyName;
    private String companyEmail;
    private String companyPhone;
    private String password;  // Securely store hashed passwords
    @JsonIgnore
    @OneToMany(mappedBy = "corporateClient", cascade = CascadeType.ALL, orphanRemoval = true)
    private List<Employee> employees = new ArrayList<>();
}
