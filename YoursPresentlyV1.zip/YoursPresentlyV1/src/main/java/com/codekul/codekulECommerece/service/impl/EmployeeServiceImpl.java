package com.codekul.codekulECommerece.service.impl;

import com.codekul.codekulECommerece.dto.EmployeeDto;
import com.codekul.codekulECommerece.entity.CorporateClient;
import com.codekul.codekulECommerece.entity.Employee;
import com.codekul.codekulECommerece.repository.CorporateClientRepo;
import com.codekul.codekulECommerece.repository.EmployeeRepo;
import com.codekul.codekulECommerece.service.interf.EmployeeService;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;

@Service
@RequiredArgsConstructor
public class EmployeeServiceImpl implements EmployeeService {

    private final EmployeeRepo employeeRepo;
    private final CorporateClientRepo corporateClientRepo;

    @Override
    public Employee addEmployee(Long corporateClientId, EmployeeDto dto) {
        CorporateClient corporateClient = corporateClientRepo.findById(corporateClientId)
                .orElseThrow(() -> new RuntimeException("Corporate Client not found"));

        Employee employee = new Employee();
        employee.setName(dto.getName());
        employee.setBirthdate(dto.getBirthdate());
        employee.setCorporateClient(corporateClient);

        return employeeRepo.save(employee);
    }
}
