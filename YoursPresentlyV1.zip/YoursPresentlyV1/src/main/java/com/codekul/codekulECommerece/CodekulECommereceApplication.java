package com.codekul.codekulECommerece;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class CodekulECommereceApplication {

	public static void main(String[] args) {
		SpringApplication.run(CodekulECommereceApplication.class, args);
	}

}
