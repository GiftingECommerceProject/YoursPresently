package com.codekul.codekulECommerece.dto;

import lombok.*;

import java.time.LocalDate;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
public class EmployeeDto {
    private String name;
    private LocalDate birthdate;
}
