package com.codekul.codekulECommerece.controller;

import com.codekul.codekulECommerece.dto.EmployeeDto;
import com.codekul.codekulECommerece.entity.Employee;
import com.codekul.codekulECommerece.service.impl.EmployeeServiceImpl;
import lombok.RequiredArgsConstructor;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/employees")
@RequiredArgsConstructor
public class EmployeeController {

    private final EmployeeServiceImpl employeeService;

    @PostMapping("/add/{corporateClientId}")
    public ResponseEntity<Employee> addEmployee(@PathVariable Long corporateClientId, @RequestBody EmployeeDto dto) {
    	 System.out.println("Received Employee: " + dto.getName() + ", Birthdate: " + dto.getBirthdate());
    	Employee employee = employeeService.addEmployee(corporateClientId, dto);
        return ResponseEntity.status(HttpStatus.CREATED).body(employee);
    }
}
