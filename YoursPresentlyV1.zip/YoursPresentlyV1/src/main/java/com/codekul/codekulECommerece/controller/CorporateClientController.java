package com.codekul.codekulECommerece.controller;

import com.codekul.codekulECommerece.dto.CorporateClientDto;
import com.codekul.codekulECommerece.entity.CorporateClient;
import com.codekul.codekulECommerece.service.impl.CorporateClientServiceImpl;
import lombok.RequiredArgsConstructor;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/corporate-clients")
@RequiredArgsConstructor
public class CorporateClientController {

    private final CorporateClientServiceImpl corporateClientService;

    @PostMapping("/register")
    public ResponseEntity<CorporateClient> registerCorporateClient(@RequestBody CorporateClientDto dto) {
        CorporateClient corporateClient = corporateClientService.registerCorporateClient(dto);
        return ResponseEntity.status(HttpStatus.CREATED).body(corporateClient);
    }
}
