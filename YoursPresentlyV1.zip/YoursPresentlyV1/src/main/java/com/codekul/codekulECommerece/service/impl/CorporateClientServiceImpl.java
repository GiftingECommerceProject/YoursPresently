package com.codekul.codekulECommerece.service.impl;

import com.codekul.codekulECommerece.dto.CorporateClientDto;
import com.codekul.codekulECommerece.entity.CorporateClient;
import com.codekul.codekulECommerece.repository.CorporateClientRepo;
import com.codekul.codekulECommerece.service.interf.CorporateClientService;
import lombok.RequiredArgsConstructor;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;

@Service
@RequiredArgsConstructor
public class CorporateClientServiceImpl implements CorporateClientService {

    private final CorporateClientRepo corporateClientRepo;
    private final PasswordEncoder passwordEncoder;

    @Override
    public CorporateClient registerCorporateClient(CorporateClientDto dto) {
        CorporateClient client = new CorporateClient();
        client.setCompanyName(dto.getCompanyName());
        client.setCompanyEmail(dto.getCompanyEmail());
        client.setCompanyPhone(dto.getCompanyPhone());
        client.setPassword(passwordEncoder.encode(dto.getPassword())); // Secure password

        return corporateClientRepo.save(client);
    }
}
