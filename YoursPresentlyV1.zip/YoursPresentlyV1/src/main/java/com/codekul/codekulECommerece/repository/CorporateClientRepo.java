package com.codekul.codekulECommerece.repository;

import com.codekul.codekulECommerece.entity.CorporateClient;
import org.springframework.data.jpa.repository.JpaRepository;
import java.util.Optional;

public interface CorporateClientRepo extends JpaRepository<CorporateClient, Long> {
    Optional<CorporateClient> findByCompanyEmail(String email);
}
