package com.codekul.codekulECommerece.entity;

import jakarta.persistence.*;
import lombok.*;

import java.time.LocalDate;

@Entity
@Table(name = "employees")
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
public class Employee {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    private String name;
    private LocalDate birthdate;

    @ManyToOne
    @JoinColumn(name = "corporate_client_id", nullable = false)
    private CorporateClient corporateClient;
}
